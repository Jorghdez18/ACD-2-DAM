package es.ejemplo.cinefest.dao;

import es.ejemplo.cinefest.modelo.Entrada;
import es.ejemplo.cinefest.orm.config.OrmFactory;
import es.ejemplo.cinefest.orm.entity.EntradaEntity;
import es.ejemplo.cinefest.orm.mapper.EntradaMapper;
import jakarta.persistence.EntityManagerFactory;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;


public class EntradaDao implements AutoCloseable {

    private static final Logger LOG = Logger.getLogger(EntradaDao.class.getName());
    private final EntityManagerFactory managerFactory;
    private final boolean ownFactory;

    public EntradaDao(String jdbcUrl) {
        managerFactory = OrmFactory.crear(jdbcUrl);
        ownFactory = true;
    }

    public EntradaDao(EntityManagerFactory factory) {
        managerFactory = factory;
        ownFactory = false;
    }

    private void registrar(String metodo, Exception ex) {
        LOG.log(Level.WARNING, metodo + " no se pudo completar: " + ex.getMessage());
    }


   
    // Usar transacciones y rollback en operaciones de escritura.
    public List<Entrada> listar() {
        try (var em = managerFactory.createEntityManager()) {
            return em.createQuery("select e from EntradaEntity e", EntradaEntity.class)
                    .getResultStream()
                    .map(EntradaMapper::toDomain)
                    .toList();
        } catch (Exception e) {
            registrar("listar", e);
            return List.of();
        }
    }
    public Optional<Entrada> buscarPorId(int id) {
       try (var em = managerFactory.createEntityManager()) {
           return Optional.ofNullable(em.find(EntradaEntity.class, id)).map(EntradaMapper::toDomain);
       } catch (Exception e) {
           registrar("buscarPorId", e);
           return Optional.empty();
       }
    }
    public int insertar(Entrada dato) {
        try (var em = managerFactory.createEntityManager()) {
            var tx = em.getTransaction();
            try {
                tx.begin();
                EntradaEntity entidad = EntradaMapper.toEntity(dato);
                em.persist(entidad);
                em.flush();
                dato.setIdEntrada(entidad.getIdEntrada());
                tx.commit();
                return entidad.getIdEntrada();
            } catch (Exception e) {
                if(tx.isActive()) tx.rollback();
                throw e;
            }
        } catch (Exception e) {
            registrar("insertar", e);
            return 0;        }
    }
    public int actualizar(Entrada dato) {
        try (var em = managerFactory.createEntityManager()) {
            var tx = em.getTransaction();
            try {
                tx.begin();
                EntradaEntity e = em.find(EntradaEntity.class, dato.getIdEntrada());
                if (e == null){ tx.commit();return 0;}
                EntradaEntity EntradaEntityActualizado = EntradaMapper.toEntity(dato);
                e.setIdEntrada(EntradaEntityActualizado.getIdEntrada());
                e.setIdSesion(EntradaEntityActualizado.getIdSesion());
                e.setIdEspectador(EntradaEntityActualizado.getIdEspectador());
                e.setFechaCompra(EntradaEntityActualizado.getFechaCompra());
                e.setEstado(EntradaEntityActualizado.getEstado());
                tx.commit();
                return 1;
            } catch (Exception e) {
                if(tx.isActive()) tx.rollback();
                throw e;
            }
        } catch (Exception e) {
            registrar("actualizar", e);
            return 0;
        }
    }
    public int eliminar(int id) {
        if (id < 1) return 0;

        try (var em = managerFactory.createEntityManager()) {
            var tx = em.getTransaction();
            try {
                tx.begin();
                EntradaEntity e = em.find(EntradaEntity.class, id);
                if (e == null) {
                    tx.rollback();
                    return 0;
                }
                em.remove(e);
                tx.commit();
                return 1;
            } catch (Exception e) {
                if (tx.isActive()) tx.rollback();
                throw e;
            }
        } catch (Exception e) {
            registrar("eliminar", e);
            return 0;
        }
    }
    public List<Object[]> entradasConDetalles() {
        // TODO: implementar conforme al contrato del README.md.
        return List.of();
    }
    public List<Object[]> entradasPorEspectador(int idEspectador) {
        // TODO: implementar conforme al contrato del README.md.
        return List.of();
    }
    public List<Object[]> ventasPorDia() {
        // TODO: implementar conforme al contrato del README.md.
        return List.of();
    }
    public int cancelarEntrada(int idEntrada) {
        // TODO: implementar conforme al contrato del README.md.
        return 0;
    }


    @Override
    public void close() {
        if (ownFactory && managerFactory.isOpen()) managerFactory.close();
    }
}
