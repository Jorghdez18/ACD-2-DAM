package es.ejemplo.cinefest.app;

import es.ejemplo.cinefest.dao.EntradaDao;

public final class Main {
    private Main(){}

    public static void main(String[] args) throws Exception {
        String url="jdbc:sqlite:datos/cinefest.sqlite3?foreign_keys=on";

        try(var entradas=new EntradaDao(url);) {
            System.out.println("Entradas: "+entradas.listar().size());
        }

    }
}
