package es.ejemplo.cinefest.orm.mapper;

import es.ejemplo.cinefest.modelo.Entrada;
import es.ejemplo.cinefest.modelo.Espectador;
import es.ejemplo.cinefest.orm.entity.EntradaEntity;
import es.ejemplo.cinefest.orm.entity.EspectadorEntity;

public final class EspectadorMapper {
    private EspectadorMapper() {}
    public static Espectador desdeEntidad(EspectadorEntity source) {
        if (source == null) return null;
        Espectador result = new Espectador();
        result.setIdEspectador(source.getIdEspectador());
        result.setNombre(source.getNombre());
        result.setEmail(source.getEmail());
        result.setFechaAlta(source.getFechaAlta());
        result.setActivo(source.getActivo());
        return result;
    }
    public static EspectadorEntity aEntidad(Espectador source) {
        if (source == null) return null;
        EspectadorEntity result = new EspectadorEntity();
        result.setIdEspectador(source.getIdEspectador());
        result.setNombre(source.getNombre());
        result.setEmail(source.getEmail());
        result.setFechaAlta(source.getFechaAlta());
        result.setActivo(source.getActivo());
        return result;
    }

    public static Espectador toDomain(EspectadorEntity entidad) {
        return new Espectador(entidad.getIdEspectador(), entidad.getNombre(), entidad.getEmail(), entidad.getFechaAlta(), entidad.getActivo());
    }

    public static EspectadorEntity toEntity(Espectador dato) {
        EspectadorEntity entidad = new EspectadorEntity();
       entidad.setIdEspectador(dato.getIdEspectador());
       entidad.setNombre(dato.getNombre());
       entidad.setEmail(dato.getEmail());
       entidad.setFechaAlta(dato.getFechaAlta());
       entidad.setActivo(dato.getActivo());
       return entidad;
    }
}
