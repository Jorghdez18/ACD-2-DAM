package es.ejemplo.cinefest.dao;

import es.ejemplo.cinefest.modelo.Espectador;
import es.ejemplo.cinefest.orm.config.OrmFactory;
import es.ejemplo.cinefest.orm.entity.EntradaEntity;
import es.ejemplo.cinefest.orm.entity.EspectadorEntity;
import es.ejemplo.cinefest.orm.mapper.EntradaMapper;
import es.ejemplo.cinefest.orm.mapper.EspectadorMapper;
import jakarta.persistence.EntityManagerFactory;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;


public class EspectadorDao  implements AutoCloseable{

    private static final Logger LOG = Logger.getLogger(EspectadorDao.class.getName());
    private final EntityManagerFactory managerFactory;
    private final boolean ownFactory;

    public EspectadorDao(String jdbcUrl) {
        managerFactory = OrmFactory.crear(jdbcUrl);
        ownFactory = true;
    }

    public EspectadorDao(EntityManagerFactory factory) {
        managerFactory = factory;
        ownFactory = false;
    }

    private void registrar(String metodo, Exception ex) {
        LOG.log(Level.WARNING, metodo + " no se pudo completar: " + ex.getMessage());
    }


    // Usar transacciones y rollback en operaciones de escritura.

    public List<Espectador> listar() {
        try (var em = managerFactory.createEntityManager()) {
            return em.createQuery("select e from EspectadorEntity e", EspectadorEntity.class)
                    .getResultStream()
                    .map(EspectadorMapper::toDomain)
                    .toList();
        } catch (Exception e) {
            registrar("listar", e);
            return List.of();
        }
    }
    public Optional<Espectador> buscarPorId(int id) {
        try (var em = managerFactory.createEntityManager()) {
            return Optional.ofNullable(em.find(EspectadorEntity.class, id)).map(EspectadorMapper::toDomain);
        } catch (Exception e) {
            registrar("buscarPorId", e);
            return Optional.empty();
        }
    }
    public int insertar(Espectador dato) {
        try (var em = managerFactory.createEntityManager()) {
            var tx = em.getTransaction();
            try {
                tx.begin();
                EspectadorEntity entidad = EspectadorMapper.toEntity(dato);
                em.persist(entidad);
                em.flush();
                dato.setIdEspectador(entidad.getIdEspectador());
                tx.commit();
                return entidad.getIdEspectador();
            } catch (Exception e) {
                if (tx.isActive()) tx.rollback();
                throw e;
            }
        } catch (Exception e) {
            registrar("insertar", e);
            return 0;
        }
    }
    public int actualizar(Espectador dato) {
        try (var em = managerFactory.createEntityManager()) {
            var tx = em.getTransaction();
            try {
                tx.begin();
                EspectadorEntity e = em.find(EspectadorEntity.class, dato.getIdEspectador());
                if (e == null){ tx.commit();return 0;}
                EspectadorEntity EspectadorEntityActualizado = EspectadorMapper.toEntity(dato);
                e.setIdEspectador(dato.getIdEspectador());
                e.setNombre(EspectadorEntityActualizado.getNombre());
                e.setEmail(EspectadorEntityActualizado.getEmail());
                e.setFechaAlta(EspectadorEntityActualizado.getFechaAlta());
                e.setActivo(EspectadorEntityActualizado.getActivo());
                tx.commit();
                return 1;
            } catch (Exception e) {
                if(tx.isActive()) tx.rollback();
                throw e;
            }
        } catch (Exception e) {
            registrar("actualizar", e);
            return 0;
        }
    }
    public int eliminar(int id) {
        if (id < 1) return 0;

        try (var em = managerFactory.createEntityManager()) {
            var tx = em.getTransaction();
            try {
                tx.begin();
                EspectadorEntity e = em.find(EspectadorEntity.class, id);
                if (e == null) {
                    tx.rollback();
                    return 0;
                }
                em.remove(e);
                tx.commit();
                return 1;
            } catch (Exception e) {
                if (tx.isActive()) tx.rollback();
                throw e;
            }
        } catch (Exception e) {
            registrar("eliminar", e);
            return 0;
        }
    }
    public Optional<Espectador> buscarPorEmail(String email) {
        try (var em = managerFactory.createEntityManager()) {
            return Optional.ofNullable(em.find(EspectadorEntity.class, email)).map(EspectadorMapper::toDomain);
        } catch (Exception e) {
            registrar("buscarPorEmail", e);
            return Optional.empty();
        }
    }
    public List<Espectador> espectadoresSinEntradas() {
        // TODO: implementar conforme al contrato del README.md.
        return List.of();
    }
    public List<Object[]> rankingEspectadores() {
        // TODO: implementar conforme al contrato del README.md.
        return List.of();
    }
    public List<Object[]> espectadoresVariasSedes(int minimo) {
        // TODO: implementar conforme al contrato del README.md.
        return List.of();
    }

    @Override
    public void close() throws Exception {

    }
}
