package aula.tareas.service;

import aula.tareas.api.TareaRequest;

import java.util.List;

public interface ITareaService {

    public List<TareaRequest> listar();
    public TareaRequest buscar(long id);
    public TareaRequest crear(String titulo);
}
