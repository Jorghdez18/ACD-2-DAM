package aula.tareas.api;

public record TareaRequest(long id, String titulo) {}
//controlador --> servicio --> repositorio
