package aula.tareas.repository;

import aula.tareas.api.TareaRequest;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import org.springframework.stereotype.Repository;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository("repositoryJdbc")
public class TareaRepositoryJdbc implements ITareaRepository {
    private final String jdbcUrl; //= jdbc:sqlite .... pero ya esta hechooo

    //Manera de conectarse UNICAMENTE para bases de datos
    public TareaRepositoryJdbc() {
        this("jdbc:sqlite:data/tareas.sqlite3");
    }

    public TareaRepositoryJdbc(String jdbcUrl) {
        this.jdbcUrl = jdbcUrl;
        if (!validarUrl(jdbcUrl)) throw new RuntimeException("No se encuentra la base de datos");
    }

    private boolean validarUrl(String jdbcUrl) {
        String url = jdbcUrl.replace("jdbc:sqlite:", "");
        Path path = Path.of(url);
        return Files.exists(path);
    }

    /**
     * String sql = "SELECT id, nombre, precio FROM producto ORDER BY id";
     * List<Producto> productos = new ArrayList<>();
     * <p>
     * try (Connection c = DriverManager.getConnection(url);
     * PreparedStatement ps = c.prepareStatement(sql);
     * ResultSet rs = ps.executeQuery()) {
     * <p>
     * while (rs.next()) {
     * productos.add(new Producto(
     * rs.getLong("id"),
     * rs.getString("nombre"),
     * rs.getDouble("precio")));
     * }
     * }
     */

    @Override
    public TareaRequest create(String titulo) {
        return null;
    }

    @Override
    public boolean delete(long identificador) {
        return false;
    }

    @Override
    public List<TareaRequest> findAll() {
        String sql = "SELECT id, titulo FROM tareas_jdbc ORDER BY id";
        List<TareaRequest> tareas = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(jdbcUrl);
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                tareas.add(new TareaRequest(rs.getLong("id"), rs.getString("titulo")));
            }
        } catch (Exception e) {
            return List.of();
        }
        return tareas;
    }

    @Override
    public TareaRequest findById(long identificador) {
        return null;
    }

    @Override
    public TareaRequest update(TareaRequest tarea) {
        return null;
    }
}
