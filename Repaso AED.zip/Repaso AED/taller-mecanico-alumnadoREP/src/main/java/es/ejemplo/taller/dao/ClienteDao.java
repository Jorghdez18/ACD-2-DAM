package es.ejemplo.taller.dao;
import es.ejemplo.taller.modelo.Cliente;
import java.sql.*;
import java.util.*;
import java.math.BigDecimal;
public class ClienteDao extends AbstractDao<Cliente>  {

    public ClienteDao(String url) {
        super(url);
    }
    
    public List<Cliente> listar() {
        String query = "SELECT id_cliente, nombre, email, telefono FROM Clientes";
       List<Cliente> clientesEncontrados = new ArrayList<>();
       try (Connection connection = abrir(url);
            PreparedStatement sentencia = connection.prepareStatement(query)){
           ResultSet resultado = sentencia.executeQuery();
           while (resultado.next()){
               clientesEncontrados.add(
                       new Cliente(
                               resultado.getInt("id_cliente"),
                               resultado.getString("nombre"),
                               resultado.getString("email"),
                               resultado.getString("telefono")));
           }
           return clientesEncontrados;
       } catch (Exception e) {
           throw new RuntimeException(e);
       }
    }
    public Optional<Cliente> buscarPorId(Integer id) {
        String query = "SELECT id_cliente, nombre, email, telefono FROM Clientes WHERE id_cliente = ?";
        try (Connection connection = abrir(url);
             PreparedStatement sentencia = connection.prepareStatement(query)) {
            sentencia.setInt(1, id);
            ResultSet resultado = sentencia.executeQuery();
            while (resultado.next()){
                return Optional.of(new Cliente(
                                resultado.getInt("id_cliente"),
                                resultado.getString("nombre"),
                                resultado.getString("email"),
                                resultado.getString("telefono")
                ));
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public int insertar(Cliente dato) {
        if (dato == null || dato.getNombre() == null || dato.getNombre().isEmpty()
                || dato.getEmail() == null || dato.getEmail().isEmpty()
                || dato.getTelefono() == null || dato.getTelefono().isEmpty()) {
            return 0;
        }
        String query = "INSERT INTO Clientes (nombre, email, telefono) VALUES (?, ?, ?)";
        try (Connection connection = abrir(url);
             PreparedStatement sentencia = connection.prepareStatement(query)) {
            sentencia.setString(1, dato.getNombre());
            sentencia.setString(2, dato.getEmail());
            sentencia.setString(3, dato.getTelefono());
            return sentencia.executeUpdate();
        } catch (SQLException e) {
            return 0;
        }
    }
    public int actualizar(Cliente dato) {
        String query = "UPDATE clientes SET nombre=?, email=?, telefono=? WHERE id_cliente = ?";
        try (Connection connection = abrir(url);
        PreparedStatement sentencia = connection.prepareStatement(query)){
            sentencia.setString(1, dato.getNombre());
            sentencia.setString(2, dato.getEmail());
            sentencia.setString(3, dato.getTelefono());
            sentencia.setInt(4, dato.getIdCliente());
            return sentencia.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public int eliminar(Integer id) {
        String query = "DELETE FROM clientes WHERE id_cliente = ?";
        try (Connection connection = abrir(url);
        PreparedStatement sentencia = connection.prepareStatement(query)){
            sentencia.setInt(1, id);
            return sentencia.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
