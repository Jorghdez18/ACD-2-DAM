package es.ejemplo.clinica.dao;

import es.ejemplo.clinica.infra.ConexioBD;

public class AbstractDao<T> extends ConexioBD {
    public AbstractDao(String url) {
        super(url);
    }
}
