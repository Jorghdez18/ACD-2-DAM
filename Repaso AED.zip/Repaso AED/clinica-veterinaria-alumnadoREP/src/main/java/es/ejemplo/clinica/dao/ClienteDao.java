package es.ejemplo.clinica.dao;
import es.ejemplo.clinica.modelo.Cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class ClienteDao extends AbstractDao<Cliente> implements IClienteDao {
    public ClienteDao(String url) {
        super(url);
    }

    public List<Cliente> listar() {
        String query = "SELECT id, nombre, email, telefono FROM Clientes";
        List<Cliente> clientesEncontrados = new ArrayList<>();
        try (Connection connection = abrir();
             PreparedStatement sentencia = connection.prepareStatement(query)){
            ResultSet resultado = sentencia.executeQuery();
            while (resultado.next()){
                clientesEncontrados.add(
                        new Cliente(
                                resultado.getInt("id"),
                                resultado.getString("nombre"),
                                resultado.getString("email"),
                                resultado.getString("telefono")));
            }
            return clientesEncontrados;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public Optional<Cliente> buscarPorId(Integer id) {
        if (id == null) return Optional.empty();
        String query = "SELECT id, nombre, email, telefono FROM Clientes WHERE id = ?";
        try (Connection connection = abrir();
             PreparedStatement sentencia = connection.prepareStatement(query)) {
            sentencia.setInt(1, id);
            ResultSet resultado = sentencia.executeQuery();
            while (resultado.next()){
                return Optional.of(new Cliente(
                        resultado.getInt("id"),
                        resultado.getString("nombre"),
                        resultado.getString("email"),
                        resultado.getString("telefono")
                ));
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public int insertar(Cliente dato) {
        if (dato == null ||
                dato.getNombre() == null || dato.getNombre().isEmpty() ||
                dato.getEmail() == null || dato.getEmail().isEmpty() ||
                dato.getTelefono() == null || dato.getTelefono().isEmpty())  return 0;

        try (Connection c = abrir();
             PreparedStatement st = c.prepareStatement("INSERT INTO clientes (nombre, email, telefono) VALUES (?,?,?) RETURNING id")) {
            st.setString(1, dato.getNombre());
            st.setString(2, dato.getEmail());
            st.setString(3, dato.getTelefono());
            try (ResultSet rs = st.executeQuery()) {
                while (rs.next()) {
                    return rs.getInt("id");
                }
            }
        } catch (Exception e) {
            throw new DaoException(e.getMessage(), e);
        }
        return 0;
    }
    public int actualizar(Cliente dato) {
        if (dato.getId() == null) {
            throw new IllegalArgumentException("El ID del cliente es obligatorio");
        }

        String query = "UPDATE clientes SET nombre=?, email=?, telefono=? WHERE id = ?";
        try (Connection connection = abrir();
             PreparedStatement sentencia = connection.prepareStatement(query)){
            sentencia.setString(1, dato.getNombre());
            sentencia.setString(2, dato.getEmail());
            sentencia.setString(3, dato.getTelefono());
            sentencia.setInt(4, dato.getId());
            return sentencia.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public int eliminar(Integer id) {
        String query = "DELETE FROM clientes WHERE id = ?";
        try (Connection connection = abrir();
             PreparedStatement sentencia = connection.prepareStatement(query)){
            sentencia.setInt(1, id);
            return sentencia.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
