package es.ejemplo.gestion.dao;

import es.ejemplo.gestion.config.ConexionBD;
import es.ejemplo.gestion.exception.AplicationException;
import es.ejemplo.gestion.model.Producto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


public class ProductoDao extends ConexionBD{
   // private  ConexionBD conexionBD;

    public ProductoDao(String url) {
        super(url);
    }


    public List<Producto> listar() {
        List<Producto> productos = new ArrayList<>();
        String query="SELECT id, nombre, precio FROM Produtos";
        try (Connection connection = this.obtenerConexion()){
        PreparedStatement ps = connection.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        while (rs.next()){
            productos.add(mapeoProducto(rs));
        }
        } catch (Exception e) {
            throw new AplicationException(e.getMessage(), e.getCause());
        }
        return productos;

        //conexion
        //sql
        //preparedStatement
        //resultset rs
        //rs.next
        //while(rs.next()){
        //producto = new Producto(rs.get(id), rs.get(nombre))
        /**
        try {
            String sql = "";

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return productos;
         */
    }

    public Optional<Producto> buscarPorId(int id) {
        return null;
    }

    public boolean insertar(Producto producto) {
        return false;
    }

    public boolean actualizar(Producto producto) {
        return false;
    }

    public boolean eliminar(int id) {
        return false;
    }

    public List<Producto> buscarPorNombre(String texto) {
       return null;
    }

    public List<Producto> buscarPorPrecio(double minimo, double maximo) {
        return null;
    }

    public int contar() {
       return 0;
    }

    public double precioMedio() {
        return 0;
    }

    private Producto mapeoProducto(ResultSet rs){

        try {
            return new Producto(rs.getInt(1), rs.getString(2), rs.getDouble(3));


        } catch (Exception e) {
            throw new AplicationException(e.getMessage(), e.getCause());
        }

    }
}
