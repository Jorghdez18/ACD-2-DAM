package es.ejemplo.gestion.dao;

import es.ejemplo.gestion.model.Vehiculo;
import java.sql.*;
import java.util.*;

public class VehiculoDao extends AbstractDao<Vehiculo> {
    public VehiculoDao(String url) { super(url); }

    @Override
    protected Optional<Vehiculo> mapRsToClass(ResultSet rs) {
        // TODO: leer matricula, marca, modelo, anio con rs.getXXX(...)
        // Capturar SQLException y RuntimeException aquí; nunca declarar throws.
        try {
            return Optional.of(new Vehiculo(
                    rs.getString("matricula"),
                    rs.getString("marca"),
                    rs.getString("modelo"),
                    rs.getInt("anio")));
        } catch (SQLException | RuntimeException e) {
            registrar("mapRstoclass vehiculo", e);
            return Optional.empty();
        }

    }

    public List<Vehiculo> listar() {
        // TODO: seguir el ejemplo de ProductoDao.listar()
        String sql = "SELECT  matricula,marca,modelo,anio FROM vehiculos ORDER BY matricula";
        try (Connection con = obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            return consultar(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("listar vehiculos", e);
            return List.of();
        }
    }

    public Optional<Vehiculo> buscarPorId(String matricula) {
        if (matricula == null) return Optional.empty();
        // TODO: SELECT WHERE matricula = ?; ps.setString(1, matricula)
        String query = "SELECT matricula,marca,modelo,anio FROM vehiculos where matricula = ?";
        try (Connection connection = obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, matricula);
            return consultarUno(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("buscar vehiculo por id", e);
            return Optional.empty();
        }

    }

    public Optional<Vehiculo> buscarPorMatricula(String matricula) {
        // TODO: delegar en buscarPorId(matricula)
        return buscarPorId(matricula);
    }

    public boolean eliminar(String matricula) {
        // TODO: DELETE WHERE matricula = ?
        String query = "DELETE FROM vehiculos WHERE matricula=?";
        try (Connection connection = this.obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, matricula);
            return ejecutar(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("eliminar vehiculo por matricula", e);
            return false;
        }
    }

    public boolean insertar(Vehiculo v) {
        // TODO: validar e insertar
        String query = "INSERT INTO vehiculos (matricula,marca,modelo,anio) VALUES (?, ?, ?, ?)";
        try (Connection connection = obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, v.getMatricula());
            ps.setString(2, v.getMarca());
            ps.setString(3, v.getModelo());
            ps.setInt(4, v.getAnio());
            return ejecutar(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("insertar vehiculo", e);
            return false;
        }
    }

    public boolean actualizar(Vehiculo v) {
        // TODO: validar y actualizar
        String query = "UPDATE vehiculos SET marca = ?, modelo = ?, anio = ? WHERE matricula = ?";
        try (Connection connection = obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, v.getMarca());
            ps.setString(2, v.getModelo());
            ps.setInt(3, v.getAnio());
            ps.setString(4, v.getMatricula());
            return ejecutar(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("actualizar vehiculo", e);
            return false;
        }
    }

    public List<Vehiculo> buscarPorMarca(String texto) {
        // TODO: LIKE sin distinguir mayúsculas
        if (texto == null) return List.of();
        String query = "SELECT matricula,marca,modelo,anio FROM vehiculos WHERE marca LIKE ? ORDER BY marca";
        try (Connection connection = obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1,  "%" + texto + "%");
            return consultar(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("buscar vehiculo por marca", e);
            return List.of();
        }
    }

    public List<Vehiculo> buscarPorAnio(int desde, int hasta) {
        // TODO: BETWEEN inclusivo
        String query = "SELECT matricula,marca,modelo,anio FROM vehiculos WHERE anio BETWEEN ? AND ?";
        try (Connection connection = this.obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setDouble(1, desde);
            ps.setDouble(2, hasta);
            return consultar(ps);
        }catch (SQLException | RuntimeException e) {
            registrar("buscar vehiculo por Anio", e);
            return List.of();
        }
    }

    public int contar() {
        // TODO: consultarEntero(ps)
        String query = "SELECT COUNT(*) FROM vehiculos";
        try (Connection connection = obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            return consultarEntero(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("contar vehiculos", e);
            return 0;
        }
    }

    public Map<String, Integer> contarPorMarca() {
        // TODO: GROUP BY marca y consultarAgrupado(ps)
        String query = "SELECT marca, COUNT(*) FROM vehiculos GROUP BY marca ORDER BY marca" ;
        try (Connection connection = obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            return consultarAgrupado(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("contar vehiculos", e);
            return Map.of();        }

    }
}
