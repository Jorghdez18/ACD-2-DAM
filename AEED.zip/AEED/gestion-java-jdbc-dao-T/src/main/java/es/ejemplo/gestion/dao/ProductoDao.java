package es.ejemplo.gestion.dao;

import es.ejemplo.gestion.exception.AplicationException;
import es.ejemplo.gestion.model.Producto;
import java.sql.*;
import java.util.*;

public class ProductoDao extends AbstractDao<Producto> {
    public ProductoDao(String url) {
        super(url);
    }

    /**
     * EJEMPLO COMPLETO: transformar ResultSet a Producto sin propagar excepciones.
     */
    @Override
    protected Optional<Producto> mapRsToClass(ResultSet rs) {
        try {
            return Optional.of(new Producto(rs.getInt("id"), rs.getString("nombre"), rs.getDouble("precio")));
        } catch (SQLException | RuntimeException e) {
            registrar("mapRsToClass producto", e);
            return Optional.empty();
        }
    }

    /**
     * EJEMPLO COMPLETO: listar productos mediante PreparedStatement.
     */
    public List<Producto> listar() {
        String sql = "SELECT id,nombre,precio FROM Productos ORDER BY id";
        try (Connection con = obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            return consultar(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("listar productos", e);
            return List.of();
        }
    }

    // TODO: implementa cada método con PreparedStatement y try-with-resources.
    // IMPORTANTE: buscarPorId y eliminar usan Integer; la clase base NO necesita ID.
    public Optional<Producto> buscarPorId(Integer id) {
        if (id == null) {
            return Optional.empty();
        }
        // TODO: SELECT ... WHERE id = ?; ps.setInt(1, id); consultarUno(ps)
        String query = "SELECT id, nombre, precio FROM Productos WHERE id=?";
        try (Connection connection = obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            return consultarUno(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("buscar producto por id", e);
            return Optional.empty();
        }

    }


    public boolean eliminar(Integer id) {
        // TODO: DELETE ... WHERE id = ?; ejecutar(ps)
        String query = "DELETE FROM productos WHERE id=?";
        try (Connection connection = this.obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            return ejecutar(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("eliminar producto por id", e);
            return false;
        }


    }

    public boolean insertar(Producto p) {
        // TODO: validar, INSERT con tres parámetros, ejecutar(ps)
        String query ="INSERT INTO Productos (id,nombre,precio) VALUES (?,?,?)";
        try (Connection connection = obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, p.getId());
            ps.setString(2, p.getNombre());
            ps.setDouble(3, p.getPrecio());
            return ejecutar(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("insertar producto", e);
            return false;
        }

    }

    public boolean actualizar(Producto p) {
        // TODO: validar, UPDATE con parámetros, ejecutar(ps)
        String query="UPDATE productos SET nombre=?, precio=? WHERE id=?";
        try (Connection connection = obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, p.getNombre());
            ps.setDouble(2, p.getPrecio());
            ps.setInt(3, p.getId());
            return ejecutar(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("actualizar producto", e);
            return false;
        }

    }

    public List<Producto> buscarPorNombre(String texto) {
        // TODO: búsqueda parcial case-insensitive, ordenada por nombre e id
        if (texto == null) return List.of();
        String query = "SELECT id, nombre, precio FROM Productos WHERE nombre LIKE ? ORDER BY nombre, id";
        try (Connection connection = obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1,  "%" + texto + "%");
            return consultar(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("buscar productos por nombre", e);
            return List.of();
        }
    }

    public List<Producto> buscarPorPrecio(double minimo, double maximo) {
        // TODO: BETWEEN inclusivo, ordenado por id
        String query = "SELECT id, nombre , precio FROM Productos WHERE precio BETWEEN ? AND ?";
        try (Connection connection = this.obtenerConexion();
             PreparedStatement ps = connection.prepareStatement("SELECT id, nombre, precio FROM Productos WHERE precio BETWEEN ? AND ?")) {
            ps.setDouble(1, minimo);
            ps.setDouble(2, maximo);
            return consultar(ps);
        }catch (SQLException | RuntimeException e) {
            registrar("buscar productos por nombre", e);
            return List.of();
        }


    }

    public int contar() {
        // TODO: SELECT COUNT(*) y consultarEntero(ps)
        String query = "SELECT COUNT(*) FROM Productos";
        try (Connection connection = obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            return consultarEntero(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("contar productos", e);
            return 0;
        }


    }

    public double precioMedio() {
        // TODO: COALESCE(AVG(precio),0) y consultarDecimal(ps)
        String query="SELECT AVG(precio) FROM Productos";
        try (Connection connection = obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query)) {
            return consultarDecimal(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("devolver precio medio", e);
            return 0;
        }

    }
}
