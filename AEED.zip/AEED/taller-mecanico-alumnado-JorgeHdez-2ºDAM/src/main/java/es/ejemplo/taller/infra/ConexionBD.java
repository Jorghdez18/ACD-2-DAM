package es.ejemplo.taller.infra;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexionBD {

    private static final Logger LOG = Logger.getLogger(ConexionBD.class.getName());
    private final String url;

    private ConexionBD(String url) {
        this.url = url;
        Path path = Path.of(url);
        if (!Files.exists(path)){
            try {
                Files.createFile(path);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
}

    /**
     * Crea el directorio de una ruta SQLite y devuelve su url absoluta
     * @param url url de la bssd
     * @return su url absoluta
     */
    public static String normalizarUrl(String url){
        if (url == null || !url.startsWith("jdbc:sqlite:")){
            return url;
        }
        String archivo = url.substring("jdbc:sqlite:".length());
        if (archivo.isBlank() || archivo.equals(":memory:") || archivo.startsWith("file:")){
            return url;
        }
        try {
            Path ruta = Paths.get(archivo);
            if (!ruta.isAbsolute()) {
                Path cwd = Paths.get("").toAbsolutePath().normalize();
                Path proyecto = cwd;
                if (!Files.exists(proyecto.resolve("pom.xml")) &&
                        Files.exists(proyecto.resolve("gestion-java-jdbc-dao/pom.xml"))) {
                    proyecto = proyecto.resolve("gestion-java-jdbc-dao");
                }
                ruta = proyecto.resolve(ruta);
            }
            ruta = ruta.toAbsolutePath().normalize();
            Path parent = ruta.getParent();
            if (parent != null) Files.createDirectories(parent);
            return "jdbc:sqlite:" + ruta;
        } catch (IOException | RuntimeException e) {
            LOG.log(Level.WARNING, "No se pudo preparar el directorio SQLite", e);
            return url;
        }
    }

    /**
     * TODO: verificar el archivo antes de conectar y comprobar las tablas.
     * Devuelve una conexión abierta cuya responsabilidad de cierre tiene el llamador.
     * Si la ruta, el archivo o el esquema no son válidos, lanza SQLException.
     */
    public static Connection abrir(String url) throws SQLException {
        try {
            return DriverManager.getConnection(normalizarUrl(url));
        } catch (SQLException | RuntimeException e) {
            LOG.log(Level.WARNING, "No se pudo abrir conexión SQLite: " + url, e);
            return null;
        }
    }

}
