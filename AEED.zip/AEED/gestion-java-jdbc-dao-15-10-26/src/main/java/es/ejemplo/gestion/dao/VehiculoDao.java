package es.ejemplo.gestion.dao;

import es.ejemplo.gestion.config.ConexionBD;
import es.ejemplo.gestion.exception.AplicationException;
import es.ejemplo.gestion.model.Producto;
import es.ejemplo.gestion.model.Vehiculo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class VehiculoDao extends AbstractDao<Vehiculo> {
    private  ConexionBD conexionBD;

    public VehiculoDao(String url) {
        super(url);
    }

    @Override
    Vehiculo mapToClass(ResultSet rs) {
        return null;
    }


    public List<Vehiculo> listar() {
        String query = "select  matricula,marca,modelo,anio from vehiculos ORDER BY matricula";
        return consultar(query);
        /**
        List<Vehiculo> lista = new ArrayList<>();

        try (Connection connection = this.obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(query);) {
            try (ResultSet rs = ps.executeQuery();) {
                while (rs.next()) {
                    lista.add(mapeoVehiculo(rs));
                }
            }
        } catch (Exception e) {
            throw new AplicationException(e.getMessage(), e);
        }
        return lista;
         */
    }

    public Optional<Vehiculo> buscarPorMatricula(String matricula) {
        String sql = "SELECT matricula,marca,modelo,anio FROM vehiculos where matricula = ?";

        try (Connection connection = this.obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, matricula);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapeoVehiculo(rs));
                }

                return Optional.empty();
            }
        } catch (Exception e) {
            throw new AplicationException(e.getMessage(), e);
        }
    }

    public boolean insertar(Vehiculo vehiculo) {
        String sql = "INSERT INTO vehiculos (matricula,marca,modelo,anio) VALUES (?, ?, ?, ?)";
        try (Connection con = this.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, vehiculo.getMatricula());
            ps.setString(2, vehiculo.getMarca());
            ps.setString(3, vehiculo.getModelo());
            ps.setInt(4, vehiculo.getAnio());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            throw new AplicationException(e.getMessage(), e);
        }
    }

    public boolean actualizar(Vehiculo vehiculo) {
        String sql = "UPDATE vehiculos SET marca = ?, modelo = ?, anio = ? WHERE matricula = ?";

        try (Connection connection = this.obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, vehiculo.getMarca());
            ps.setString(2, vehiculo.getModelo());
            ps.setInt(3, vehiculo.getAnio());
            ps.setString(4, vehiculo.getMatricula());

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            throw new AplicationException(e.getMessage(), e);
        }
    }

    public boolean eliminar(String matricula) {
        String sql = "DELETE FROM vehiculos where matricula = ?";

        try (Connection connection = this.obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, matricula);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            throw new AplicationException(e.getMessage(), e);
        }
    }

    public List<Vehiculo> buscarPorMarca(String texto) {
       return null;
    }

    public List<Vehiculo> buscarPorAnio(int desde, int hasta) {
        return null;
    }

    public int contar() {
        String sql = "SELECT COUNT(*) from vehiculos";
        try (Connection connection = this.obtenerConexion();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        } catch (Exception e) {
            throw new AplicationException(e.getMessage(), e);
        }
    }

    public Map<String, Integer> contarPorMarca() {
        return null;
    }

    private Vehiculo mapeoVehiculo(ResultSet rs) {
        try {
            return new Vehiculo(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4));
        } catch (Exception e) {
            throw new AplicationException(e.getMessage(), e.getCause());
        }
    }
}
