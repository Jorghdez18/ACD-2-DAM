package com.docencia.condicionales;
/** Servicio para practicar if/else. */
public interface IfElseService {
    /**
     * Funcion que clasifica la edad en menor o mayor de edad
     * @param edad entero
     * @return valor de la edad
     */
    String clasificarEdad(Integer edad);

    /**
     * Funcion que evalua una nota en aprobado o suspendido
     * @param nota entero
     * @return valor de la nota
     */
    String evaluarNota(Integer nota);
    Boolean puedeAcceder(Boolean activo, Integer edad);
    String clasificarTemperatura(Double temperatura);
    String calcularResultadoComparacion(Integer primero, Integer segundo);
}
