package com.docencia.algoritmos;

import java.util.Collections;
import java.util.List;

public class BusquedaServiceImpl implements BusquedaService {

    @Override
    public Integer buscarIndiceElemento(List<Integer> numeros, Integer valor) {
         if (numeros.isEmpty() || numeros == null){
        throw new IllegalArgumentException("La lista no puede estar vacía");
       }
       int indice = 0;

       for (Integer numero : numeros) {
            if (numero.equals(valor)){
                return indice;
            }
            indice ++;
       }
       return -1;

    }

    @Override
    public Boolean existePalabra(List<String> palabras, String palabra) {
       if (palabras.isEmpty() || palabras == null){
        throw new IllegalArgumentException();
       }

       palabra = palabra.toLowerCase();

       for (String p : palabras) {
        if (p.toLowerCase().equals(palabra)){
            return true;
        }
       }
       return false;

    }

    @Override
    public Integer encontrarMaximo(List<Integer> numeros) {

         if (numeros.isEmpty() || numeros == null){
        throw new IllegalArgumentException("La lista no puede estar vacía");
       }

       Integer maximo = numeros.get(0);

       for (Integer numero : numeros) {
        if (numero > maximo){
            maximo = numero;
        }
       }
       return maximo;
    }

    @Override
    public Integer encontrarMinimo(List<Integer> numeros) {
         if (numeros.isEmpty() || numeros == null){
        throw new IllegalArgumentException("La lista no puede estar vacía");
       }

       Integer minimo = numeros.get(0);

       for (Integer numero : numeros) {
        if (numero < minimo){
            minimo = numero;
        }
       }
       return minimo;
    }

    @Override
    public Integer contarApariciones(List<Integer> numeros, Integer valor) {
        if (numeros == null || numeros.isEmpty()){
            throw new IllegalArgumentException();
        }
        int contador = 0;

        for (Integer numero : numeros) {
            if (numero.equals(valor)){
                contador ++;
            }
        }
        return contador;
    }

}
