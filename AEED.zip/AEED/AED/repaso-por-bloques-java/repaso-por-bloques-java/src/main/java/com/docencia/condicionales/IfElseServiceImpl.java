package com.docencia.condicionales;

public class IfElseServiceImpl implements IfElseService {

    @Override
    public String clasificarEdad(Integer edad) {
        // TODO Auto-generated method stub
        if (edad < 0 || edad == null){
            throw new UnsupportedOperationException("Unimplemented method 'clasificarEdad'");
        }
        if (edad <= 17){
            return "MENOR";
        }
            return "ADULTO";

    }

    @Override
    public String evaluarNota(Integer nota) {
        if (nota < 0 || nota == null) {
            throw new UnsupportedOperationException("Unimplemented method 'evaluarNota'");
        }
        if (nota <= 4){
            return "SUSPENDIDO";
        }
        return "APROBADO";
    }

    @Override
    public Boolean puedeAcceder(Boolean activo, Integer edad) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'puedeAcceder'");
    }

    @Override
    public String clasificarTemperatura(Double temperatura) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'clasificarTemperatura'");
    }

    @Override
    public String calcularResultadoComparacion(Integer primero, Integer segundo) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'calcularResultadoComparacion'");
    }
    
}
