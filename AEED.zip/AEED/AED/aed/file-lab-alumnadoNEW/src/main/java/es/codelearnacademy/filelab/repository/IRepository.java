package es.codelearnacademy.filelab.repository;

import java.util.List;
import java.util.Optional;

public interface IRepository<T, ID> {

    /**
     * Busca todas las entidades
     * @return todas las entidades
     */
    List<T> findAll();

    /**
     * Busca la entidad dentro de la lista por su id
     * @param id id de la entidad
     * @return la entidad
     */
    Optional<T> findById(ID id);

    /**
     * crea la entidad
     * @param entity entidad
     * @return true/false
     */
    boolean create(T entity);

    /**
     * Actualiza una entidad
     * @param entity entidad
     * @return true/false
     */
    boolean update(T entity);

    /**
     * Elimina una entidad por su id
     * @param id id de la entidad
     * @return true/false
     */
    boolean delete(ID id);
}
