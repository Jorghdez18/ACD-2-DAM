package es.codelearnacademy.filelab.io;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.sql.ClientInfoStatus;
import java.util.List;

public class TextFileService {

    public boolean escribir(Path path, String contenido) {
        if (path == null || contenido == null){
            throw new IllegalArgumentException();
        }
        try {
            Files.writeString(path, contenido, StandardCharsets.UTF_8);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public String leer(Path path) {
        if (path == null){
            throw new IllegalArgumentException();
        }
        try {
           return Files.readString(path, StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    public boolean escribirLineas(Path path, List<String> lineas) {
        if (path == null || lineas == null){
            throw new IllegalArgumentException();
        }
        try {
             Files.write(path, lineas, StandardCharsets.UTF_8);
             return true;
        } catch (Exception e) {
            return false;
        }
    }

    public List<String> leerLineas(Path path) {
        if (path == null){
            throw new IllegalArgumentException();
        }
        try {
            return Files.readAllLines(path, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return List.of();
        }
    }

    public boolean anexar(Path path, String contenido) {
        if (path == null || contenido == null){
            throw new IllegalArgumentException();
        }
        try {
            Files.writeString(path, contenido, StandardCharsets.UTF_8, StandardOpenOption.APPEND);
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
