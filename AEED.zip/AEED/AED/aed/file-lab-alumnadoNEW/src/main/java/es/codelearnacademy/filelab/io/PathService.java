package es.codelearnacademy.filelab.io;

import java.nio.file.Path;
import java.nio.file.Paths;

public class PathService {

    public Path crear(String primero, String... partes) {
        if (primero == null){
            throw new IllegalArgumentException();
        }
        return Path.of(primero, partes);
    }

    public String nombre(Path path) {
        if (path == null ){
            throw new IllegalArgumentException();
        }
        Path nombreArchivo = path.getFileName();
        if (nombreArchivo == null ){
            throw new IllegalArgumentException();
        }
        return nombreArchivo.toString();
    }

    public Path padre(Path path) {
        if (path == null ){
            throw new IllegalArgumentException();
        }
        return path.getParent();
    }

    public Path absoluto(Path path) {
        if (path == null ){
            throw new IllegalArgumentException();
        }
        return path.toAbsolutePath();
    }

    public Path normalizar(Path path) {
        if (path == null ){
            throw new IllegalArgumentException();
        }
        return path.normalize();
    }

    public boolean esAbsoluto(Path path) {
        if (path == null ){
            throw new IllegalArgumentException();
        }
        return path.isAbsolute();
    }

    public Path resolver(Path base, String otro) {
        if (base == null || otro == null){
            throw new IllegalArgumentException();
        }
        return base.resolve(otro);
    }

    public Path relativizar(Path base, Path destino) {
        if (base == null || destino == null){
            throw new IllegalArgumentException();
        }
        return base.relativize(destino);
    }

    public String extension(Path path) {
        if (path == null ){
            throw new IllegalArgumentException();
        }
        String archivo = nombre(path);
        int punto = archivo.lastIndexOf('.');
        if (punto == -1){
            return "";
        }
        return archivo.substring(punto +1);
    }
}
