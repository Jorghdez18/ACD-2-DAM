package es.codelearnacademy.filelab.repository;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/** Infraestructura CRUD reutilizable. Proporcionada por el docente. */
public abstract class AbstractFileRepository<T, ID> implements IRepository<T, ID> {

    protected abstract ID getId(T entity);

    // Los errores de E/S solo se declaran en los metodos protegidos internos.
    protected abstract List<T> readAll() ;

    protected abstract void writeAll(List<T> entities);

    @Override
    public List<T> findAll() {
        List<T> entidades = readAll();
        if (entidades== null){
            throw new IllegalArgumentException("lista vacia");
        }
        return entidades;
    }

    @Override
    public Optional<T> findById(ID id) {
        if(id == null){
            return Optional.empty();
        }
        List<T> entidades = readAll();

        for (T entidad : entidades) {
            if (getId(entidad).equals(id)){
                return Optional.of(entidad);
            }
        }
        throw new IllegalArgumentException("id no encontrado");
    }

    @Override
    public boolean create(T entity) {
        if (entity == null){
            throw new IllegalArgumentException("Entidad nula");
        }
        List<T> entidades = readAll();
        for (T entidade : entidades) {
            if (getId(entity).equals(getId(entidade))){
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean update(T entity) {
        throw new UnsupportedOperationException("TODO: update");
    }

    @Override
    public boolean delete(ID id) {
        if(id == null){
            return false;
        }
        List<T> entidades = readAll();

        for (T entidad : entidades) {
            if (getId(entidad).equals(id)){
                entidades.remove(entidad);
                return true;
            }
        }
        return false;
    }
}
