package es.codelearnacademy.filelab.persona.xml;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import es.codelearnacademy.filelab.demo.crud.XmlCrudDemo;
import es.codelearnacademy.filelab.model.Persona;
import es.codelearnacademy.filelab.persona.IPersonaRepository;
import es.codelearnacademy.filelab.repository.AbstractFileRepository;
import java.nio.file.*;
import java.io.*;
import java.util.*;
public class PersonaXmlRepository extends AbstractFileRepository<Persona,String> implements IPersonaRepository {
    private final Path path;
    private final XmlMapper mapper = null;

    public PersonaXmlRepository(Path path) {
        this.path=path;
    }
    @Override
    protected String getId(Persona p) {
        return p.dni();
    }
    @Override
    protected List<Persona> readAll() {

        //if (Files.notExists(path) || Files.size(path) == 0) return new ArrayList<>();
        //XmlCrudDemo.DocumentoProductos data = mapper.readValue(path.toFile(), XmlCrudDemo.DocumentoProductos.class);
        //return new ArrayList<Persona>(data.personas);
        throw new IllegalArgumentException();
    }
    @Override
    protected void writeAll(List<Persona> personas) {
        throw new UnsupportedOperationException("TODO: escribir XML con XmlMapper");
    }
}
