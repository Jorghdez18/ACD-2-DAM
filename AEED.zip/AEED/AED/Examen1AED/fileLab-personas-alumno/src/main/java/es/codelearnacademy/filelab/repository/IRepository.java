package es.codelearnacademy.filelab.repository;

import java.util.List;
import java.util.Optional;

/** Contrato CRUD generico. Ninguna operacion publica propaga IOException. */
public interface IRepository<T, ID> {

    /**
     * Busca todas las entidades
     * @return lista con todas las entidades
     */
    List<T> findAll();

    /**
     * Busca una entidad por su id
     * @param id de la entidad
     * @return entidad
     */
    Optional<T> findById(ID id);

    /**
     * Crea entidad nueva
     * @param entity entidad nueva
     * @return true/false
     */
    boolean create(T entity);

    /**
     * Actualiza una entidad
     * @param entity entidad a actualizar
     * @return true/false
     */
    boolean update(T entity);

    /**
     * Elimina una entidad por su id
     * @param id id de la entidad
     * @return true/false
     */
    boolean delete(ID id);
}
