package es.codelearnacademy.filelab.persona;
import es.codelearnacademy.filelab.model.Persona;
import es.codelearnacademy.filelab.repository.IRepository;
import java.util.List;
/** Interfaz IPersonaRepository
 * busca por edad minima y busca todas las personas activas */
public interface IPersonaRepository extends IRepository<Persona,String> {

    /**
     * Busca una persona que tenga la edad mas pequenia
     * @param edad edad de la persona
     * @return lista con las personas de menos edad
     */
    default List<Persona> findByEdadMinima(int edad) {
        throw new UnsupportedOperationException("Pendiente: filtro por edad");
    }

    /**
     * Busca todas las personas activas
     * @param activo actividad de la pesona
     * @return lista con todas las personas activas
     */
    default List<Persona> findByActivo(boolean activo) {
        throw new UnsupportedOperationException("Pendiente: filtro por estado");
    }
}
