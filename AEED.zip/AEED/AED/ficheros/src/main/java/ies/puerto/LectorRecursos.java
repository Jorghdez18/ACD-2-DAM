package ies.puerto;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.lang.classfile.FieldTransform;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class LectorRecursos extends FicheroImpl{
    static void main() {
        Path path = Path.of("src/main/resources", "csv.txt");
        String ruta = path.toAbsolutePath().toString();
        System.out.println("Ruta del fichero: " + ruta);
        File file = new File(ruta);

        if (file.exists()){ //se haria el existe de la implemetnacion del fichero
            System.out.println("El fichero existe");
        } else {
            System.out.println("El fichero no existe");
        }

        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)){
            System.out.println(reader.readLine());
            String linea = reader.readLine();
            String[] valores = linea.split(",");
        } catch (IOException e){
            throw new RuntimeException(e);
        }

        }
    }

