package es.codelearnacademy.filelab.repository;

import java.util.List;
import java.util.Optional;

public interface IRepository<T, ID> {

    /**
     * Busca todos los elementos
     * @return list
     */
    List<T> findAll();

    /**
     * Busca por identificador
     * @param id identificador
     * @return el elemento con ese identificador
     */
    Optional<T> findById(ID id);

    /**
     * Crea un nuevo elemento
     * @param entity elemento a crear
     * @return true / false
     */
    boolean create(T entity);

    /**
     * Actualiza un elemento
     * @param entity elemento a actualizar
     * @return true / false
     */
    boolean update(T entity);

    /**
     * Elimina un elemento por su identificador
     * @param id identificador
     * @return true / false
     */
    boolean delete(ID id);
}
