package es.codelearnacademy.filelab.model;

public record Vehiculo(String matricula, String marca, String modelo, int anio) implements Identificable <String> {

    @Override
    public String id() {
        return "";
    }
}
