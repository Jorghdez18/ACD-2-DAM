package es.codelearnacademy.filelab.model;

public record Producto(Long id, String nombre, double precio, int stock) implements Identificable<Long> {
}
