package es.codelearnacademy.filelab.model;

public interface Identificable <ID>{
    ID id();
}
