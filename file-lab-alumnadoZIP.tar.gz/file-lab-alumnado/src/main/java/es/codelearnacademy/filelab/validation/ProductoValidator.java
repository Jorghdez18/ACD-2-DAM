package es.codelearnacademy.filelab.validation;

import es.codelearnacademy.filelab.model.Producto;

public final class ProductoValidator  {

    private ProductoValidator() {
        super();
    }

    public static void validar(Producto producto) {
        if (producto == null){
            throw new IllegalArgumentException();
        }
        return;

    }
}
