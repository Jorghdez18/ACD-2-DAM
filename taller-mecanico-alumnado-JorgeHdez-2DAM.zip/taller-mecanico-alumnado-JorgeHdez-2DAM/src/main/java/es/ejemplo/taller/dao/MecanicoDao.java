package es.ejemplo.taller.dao;
import es.ejemplo.taller.infra.ConexionBD;
import es.ejemplo.taller.modelo.Cliente;
import es.ejemplo.taller.modelo.Mecanico;
import java.sql.*;
import java.util.*;
import java.math.BigDecimal;
public class MecanicoDao extends AbstractDao<Mecanico>  {
    private final String url;
    public MecanicoDao(String url) { this.url = url; }
    
    public List<Mecanico> listar() {
        // TODO: implementar según el contrato del README.
        String query="SELECT id_mecanico, nombre, especialidad, tarifa_hora FROM mecanicos";
        try {Connection connection = ConexionBD.abrir(url);
            PreparedStatement ps = connection.prepareStatement(query);
            return consultar(ps);
        } catch (SQLException e) {
            registrar("listar mecanicos", e);
            return List.of();
        }
    }
    public Optional<Mecanico> buscarPorId(Integer id) {
        // TODO: implementar según el contrato del README.
        if (id == null){
            return Optional.empty();
        }
        String query = "SELECT id_mecanico, nombre, especialidad, tarifa_hora FROM mecanicos WHERE id_mecanico = ?";
        try {
            Connection connection = ConexionBD.abrir(url);
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, id);
            return consultarUno(ps);
        } catch (SQLException e) {
            registrar("buscar mecanico por id", e);
            return Optional.empty();
        }
    }
    public int insertar(Mecanico dato) {
        // TODO: implementar según el contrato del README.
        if (dato == null){
            return 0;
        }
        String query = "INSERT INTO mecanicos (nombre, especialidad, tarifa_hora) VALUES(?,?,?)";
        try (Connection connection = ConexionBD.abrir(url);
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, dato.getNombre());
            ps.setString(2, dato.getEspecialidad());
            ps.setBigDecimal(3, dato.getTarifaHora());
            return ejecutar(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("insertar mecanico", e);
            return 0;
        }
    }
    public int actualizar(Mecanico dato) {
        // TODO: implementar según el contrato del README.
        String query = "UPDATE mecanicos SET nombre=?, especialidad=?, tarifa_hora=? WHERE id_mecanico=?";
        try {Connection connection = ConexionBD.abrir(url);
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, dato.getNombre());
            ps.setString(2, dato.getEspecialidad());
            ps.setBigDecimal(3, dato.getTarifaHora());
            ps.setInt(4, dato.getIdMecanico());
            return ejecutar(ps);
        } catch (SQLException e) {
            registrar("actualizar mecanico", e);
            return 0;
        }
    }
    public int eliminar(Integer id) {
        // TODO: implementar según el contrato del README.
        return 0;
    }
    public List<Mecanico> buscarPorEspecialidad(String especialidad) {
        // TODO: implementar según el contrato del README.
        return List.of();
    }

    @Override
    protected Optional<Mecanico> mapRsToClass(ResultSet rs) {
        try {
            return Optional.of(new Mecanico(rs.getInt("id_mecanico"), rs.getString("nombre"),
                    rs.getString("especialidad"), rs.getBigDecimal("tarifaHora")));
        } catch (SQLException | RuntimeException e) {
            registrar("mapRsToClass cliente", e);
            return Optional.empty();
        }    }
}
