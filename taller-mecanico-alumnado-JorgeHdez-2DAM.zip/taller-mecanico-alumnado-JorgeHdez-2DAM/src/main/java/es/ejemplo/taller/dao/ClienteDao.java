package es.ejemplo.taller.dao;
import es.ejemplo.taller.infra.ConexionBD;
import es.ejemplo.taller.modelo.Cliente;
import java.sql.*;
import java.util.*;
import java.math.BigDecimal;

import static es.ejemplo.taller.infra.ConexionBD.abrir;

public class ClienteDao extends AbstractDao<Cliente> {
    private final String url;

    public ClienteDao(String url) {
        this.url = url;
    }
    
    public List<Cliente> listar() {
        // TODO: implementar según el contrato del README.
        String query="SELECT id_cliente, nombre, email, telefono FROM clientes";
        try {Connection connection = ConexionBD.abrir(url);
            PreparedStatement ps = connection.prepareStatement(query);
            return consultar(ps);
        } catch (SQLException e) {
            registrar("listar clientes", e);
            return List.of();
        }

    }
    public Optional<Cliente> buscarPorId(Integer id) {
        if (id == null){
            return Optional.empty();
        }
        // TODO: implementar según el contrato del README.
        String query = "SELECT id_cliente, nombre, email, telefono FROM clientes WHERE id_cliente =?";
        try {
            Connection connection = ConexionBD.abrir(url);
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, id);
            return consultarUno(ps);
        } catch (SQLException e) {
            registrar("buscar cliente por id", e);
            return Optional.empty();
        }
    }
    public int insertar(Cliente dato) {
        // TODO: implementar según el contrato del README.
        if (dato == null){
            return 0;
        }
        String query = "INSERT INTO clientes (nombre, email, telefono) VALUES(?,?,?)";
        try (Connection connection = ConexionBD.abrir(url);
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, dato.getNombre());
            ps.setString(2, dato.getEmail());
            ps.setString(3, dato.getTelefono());
            return ejecutar(ps);
        } catch (SQLException | RuntimeException e) {
            registrar("insertar producto", e);
            return 0;
        }

    }
    public int actualizar(Cliente dato) {
        // TODO: implementar según el contrato del README.
        String query = "UPDATE clientes SET nombre=?, email=?, telefono=? WHERE id_cliente=?";
        try {Connection connection = ConexionBD.abrir(url);
                PreparedStatement ps = connection.prepareStatement(query);
                ps.setString(1, dato.getNombre());
                ps.setString(2, dato.getEmail());
                ps.setString(3, dato.getTelefono());
                ps.setInt(4, dato.getIdCliente());
                return ejecutar(ps);
        } catch (SQLException e) {
            registrar("actualizar cliente", e);
            return 0;
        }

    }
    public int eliminar(Integer id) {
        // TODO: implementar según el contrato del README.
        String query = "DELETE FROM clientes WHERE id_cliente=?";
        try {Connection connection = ConexionBD.abrir(url);
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, id);
            return ejecutar(ps);
        } catch (SQLException e) {
            registrar("eliminar cliente", e);
            return 0;
        }
    }

    @Override
    protected Optional<Cliente> mapRsToClass(ResultSet rs) {
        try {
            return Optional.of(new Cliente(rs.getInt("id_cliente"), rs.getString("nombre"),
                    rs.getString("email"), rs.getString("telefono")));
        } catch (SQLException | RuntimeException e) {
            registrar("mapRsToClass cliente", e);
            return Optional.empty();
        }
    }
}
